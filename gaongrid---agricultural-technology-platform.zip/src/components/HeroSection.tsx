import React from 'react';
import { ArrowRight, CheckCircle2, Sprout, Sparkles, UserPlus, PlayCircle } from 'lucide-react';
import { HeroVisual } from './HeroVisual';

interface HeroSectionProps {
  onOpenJoinModal: (role?: string) => void;
  onExploreMarketplace: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenJoinModal,
  onExploreMarketplace,
}) => {
  return (
    <section
      id="home"
      className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden bg-grid-pattern"
    >
      {/* Decorative gradient blur in background */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-br from-emerald-200/40 via-amber-100/20 to-transparent blur-3xl -z-10 pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Hero Copy & Actions */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Small Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-900/5 border border-emerald-800/15 text-emerald-900 text-xs font-semibold tracking-wide">
              <span className="text-base leading-none">🌾</span>
              <span>Built for Farmers • Powered by Technology</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
              <span className="text-[11px] font-bold text-emerald-700 uppercase">SIH Prototype</span>
            </div>

            {/* Main Headline */}
            <h1
              id="hero-headline"
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-stone-900 tracking-tight font-display leading-[1.12]"
            >
              Sell Direct.{' '}
              <span className="text-emerald-800 underline decoration-emerald-400/40 underline-offset-8">
                Buy Smart.
              </span>{' '}
              <br className="hidden sm:inline" />
              Grow Better.
            </h1>

            {/* Supporting Text */}
            <p className="text-base sm:text-lg text-stone-600 font-normal leading-relaxed max-w-2xl">
              GaonGrid connects farmers directly with buyers, dealers and agricultural service providers — helping reduce middlemen, discover better deals, monetize crop residue and access essential farm resources.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                type="button"
                id="hero-explore-btn"
                onClick={onExploreMarketplace}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-bold text-white bg-emerald-800 hover:bg-emerald-700 active:bg-emerald-900 rounded-xl shadow-md shadow-emerald-950/20 transition-all cursor-pointer group"
              >
                <span>Explore Marketplace</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                type="button"
                id="hero-join-farmer-btn"
                onClick={() => onOpenJoinModal('farmer')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-bold text-emerald-950 bg-stone-100 hover:bg-stone-200/90 active:bg-stone-300 border border-stone-300/80 rounded-xl transition-all cursor-pointer"
              >
                <UserPlus className="w-4 h-4 text-emerald-800" />
                <span>Join as Farmer</span>
              </button>
            </div>

            {/* Trust Checklist */}
            <div className="pt-4 border-t border-stone-200/80 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs sm:text-sm font-medium text-stone-600">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Direct Connections</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Transparent Deals</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Verified Providers</span>
              </div>
            </div>

          </div>

          {/* Right Column: Hero Visual Graphic / Interactive Mockup */}
          <div className="lg:col-span-5 relative mt-4 lg:mt-0">
            <HeroVisual />
          </div>

        </div>
      </div>
    </section>
  );
};
